# wasm-file-read

- wasm-bindgen: <https://crates.io/crates/wasm-bindgen>
- WebAssembly DWARF Debugging: <https://code.visualstudio.com/docs/nodejs/nodejs-debugging#_debugging-webassembly>
- C/C++ WebAssembly をデバッグする: <https://developer.chrome.com/docs/devtools/wasm?hl=ja>

rustflags = ["-C", "debuginfo=2"]

```shell
cargo install wasm-bindgen-cli
```

```shell
cargo build
wasm-bindgen --keep-debug --target web --out-dir ./out target/wasm32-unknown-unknown/debug/wasm_file_read.wasm
pushd out
python -m http.server 8000
```
