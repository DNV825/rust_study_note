use wasm_bindgen::prelude::*;
use wasm_bindgen_futures::JsFuture;
use web_sys::{File, FileReader, Event};
use js_sys::Promise;

// JavaScript から呼び出す非同期関数
#[wasm_bindgen]
pub async fn process_file(file: File) -> Result<String, JsValue> {
    let reader = FileReader::new().map_err(|_| JsValue::from_str("Failed to create FileReader"))?;

    let promise = js_sys::Promise::new(&mut |resolve, reject| {
        let reader_clone = reader.clone();
        let onloadend = Closure::wrap(Box::new(move |_event: web_sys::Event| {
            let result = reader_clone.result();
            if let Ok(result) = result {
                resolve.call1(&JsValue::NULL, &result).unwrap();
            } else {
                reject.call1(&JsValue::NULL, &JsValue::from_str("Failed to read file")).unwrap();
            }
        }) as Box<dyn FnMut(_)>);

        reader.set_onloadend(Some(onloadend.as_ref().unchecked_ref()));
        let _ = reader.read_as_text(&file);
        onloadend.forget(); // Closure を解放しないようにする
    });

    let js_value = JsFuture::from(promise).await?;
    let text = js_value.as_string().ok_or_else(|| JsValue::from_str("Failed to convert to string"))?;

    // 文字列処理（例: 大文字変換）
    let processed = text.to_uppercase();

    Ok(processed)
}
